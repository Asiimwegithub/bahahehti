  
<title>
  <style type="text/css">
    .bg-fb{
      color: red;
      padding: 10px;
    }
  </style>

</title>





  <div class="col-md-4">
    <div style="background: #37a000; padding: 80px;">
<p style="background: blue; color: white; padding: 20px; border-radius: 10px;">Please Navigate<a style="color: white; caption-side: 10px;" href="contact-us.php"> here </a> to advertise with us</p>
</div>
          <!-- Search Widget -->
          <div class="card mb-4">
            <h5 class="card-header">Search</h5>
            <div style="background: #37a000;" class="card-body">
                   <form name="search" action="search.php" method="post">
              <div class="input-group">
           
        <input type="text" name="searchtitle" class="form-control" placeholder="Search for..." required>
                <span class="input-group-btn">
                  <button class="btn btn-secondary" type="submit">Enter</button>
                </span>
              </form>
              </div>
            </div>
          </div>






          <div class="card my-4">
            <h5 style="background: #37a000; color: white;" class="card-header">Categories</h5>
            <div class="card-body">
              <div class="row">
                <div class="col-lg-6">
                  <ul class="list-unstyled mb-0">
<?php $query=mysqli_query($con,"select id,CategoryName from tblcategory");
while($row=mysqli_fetch_array($query))
{
?>

                    <li>
                      <a href="category.php?catid=<?php echo htmlentities($row['id'])?>"><?php echo htmlentities($row['CategoryName']);?></a>
                    </li>
<?php } ?>
                  </ul>
                </div>
       
              </div>
            </div>
          </div>

          <!-- Side Widget -->
          <div class="card my-4">
            <h5 style="background: #37a000; color: white;" class="card-header">Recent News Post</h5>
            <div class="card-body">
                      <ul class="mb-0">
<?php
$query=mysqli_query($con,"select tblposts.id as pid,tblposts.PostTitle as posttitle from tblposts left join tblcategory on tblcategory.id=tblposts.CategoryId left join  tblsubcategory on  tblsubcategory.SubCategoryId=tblposts.SubCategoryId limit 8");
while ($row=mysqli_fetch_array($query)) {

?>

  <li>
                      <a href="news-details.php?nid=<?php echo htmlentities($row['pid'])?>"><?php echo htmlentities($row['posttitle']);?></a>
                    </li>
            <?php } ?>
          </ul>
            </div>
          </div>


        
          <div style="background: #37a000; padding: 10px;" class="mb-30 mt-md-30 p-30 card-view">
            <h4 class="p-title"><b style="color: white">Stay connected on our social Media Platforms</b></h4>
            <ul style="list-style: none;" class="font-12 text-center color-white list-block list-a-block list-a-ptb-10 list-li-mb-10 list-a-br-5 list-a-hvr-primary">
              <li  style="background: white; padding: 8px; color: blue; border-radius: 10px;><a class="bg-fb" style="background: blue; padding: 8px; color: white; border-radius: 10px;" href="https://www.facebook.com/thedailyparrot"><i class="mr-10 sqr-fb-20 ion-social-facebook"></i> Facebook</a><li>
                <br>
              <li  style="background: cyan; padding: 8px; color: white; border-radius: 10px;><a class="bg-twtr"  href="https://twitter.com/theparrotNews"><i class="mr-10 sqr-twtr-20 ion-social-twitter"></i> Twitter</a><li>
                <br>
              <li  style="background: orange; padding: 8px; color: white; border-radius: 10px;><a class="bg-gogl"  href="https://www.instagram.com/t><i class="fa fa-instagram"></i>Instagram</a><li>
                <br>
              <li  style="background: red; padding: 8px; color: white; border-radius: 10px; ><a class="bg-rss"  href=""><i class="ion-social-youtube"></i>YouTube</a><li>
            </ul> 
          </div>

<br><br>

          <p style="background: #37a000; color: #fff; padding: 10px; width: 355px;">Trending Video Clips</p>


<iframe width="355" height="315" src="https://www.youtube.com/embed/UI1y1IP0JNM" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="355" height="315" src="https://www.youtube.com/embed/crQcDtveJh4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br><br>
<p style="background: #37a000; color: white; padding: 10px;" >Be directed by a live map to our Offices</p>
<iframe width="355" height="315" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4744.650268526094!2d32.555948182804364!3d0.31137608926371924!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x177dbca232585b9d%3A0xe1d42b1b01ec1320!2sNdejje%20University%20Kampala%20Branch!5e0!3m2!1sen!2sug!4v1607517280033!5m2!1sen!2sug" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

<br><br>

<section style="background: #37a000; width: 355px;" class="pt-0 pb-20">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-8">
          <div class="p-30 mb-30 card-view">
            <h4 class="p-title"><b>Lets connect</b></h4>
            <form style="" action="process.php" method="post">
              <div class="row">
                <div class="col-sm-6">
                  <input style="padding: 10px;" sclass="mb-30" name="name" required   type="text" placeholder="Your name">
                </div>
          
                <div class="col-sm-6">
                  <input style="padding: 10px; " class="mb-30" name="email" required   type="text" placeholder="Your email">
                </div>
                <div class="col-sm-12">
                  <textarea style="width: 316px; padding: 10px;" class="mb-30" name="message" required   placeholder="Your message"></textarea>
                </div>
                
              </div>
              
              <button style="width: 316px; padding: 10px;" class="btn-fill-primary plr-20" ><b>Enter</b></button>
            </form>
          </div>
        </div>

        <p style= "color: black;">></p>
        <div class="col-md-12 col-lg-4">
          <br><br>
          <div class="p-30 mb-30 card-view">
            <h5 class=""><b>OUR OFFICE</b></h4>
            <ul style="list-style: none;" class="list-contact list-li-mb-20">
              <li><i style="color: white;" class="">Mengo, Kampala, Uganda</li>
              <li><a style="color: white;" href="#"><i class="ie"></i>hdgs8ww7474</a></li>
              <li><a style="color: white;" href="#"><i class=""></i>Bahatihshsgsgsgs@gmail.com</a></li>
              <li class="mb-0"><a href="#"><i class="iod"></a></li>
            </ul>
          </div> 
        </div>
      </div>
    </div>
  </section>

        </div>
